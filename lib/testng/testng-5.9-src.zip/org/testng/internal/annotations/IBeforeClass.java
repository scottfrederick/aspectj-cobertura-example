package org.testng.internal.annotations;

public interface IBeforeClass extends IBaseBeforeAfter {

}
