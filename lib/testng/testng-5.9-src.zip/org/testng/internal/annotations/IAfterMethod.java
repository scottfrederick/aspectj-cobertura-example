package org.testng.internal.annotations;

public interface IAfterMethod extends IBaseBeforeAfter {

}
